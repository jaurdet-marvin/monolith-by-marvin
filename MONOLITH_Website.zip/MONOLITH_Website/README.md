# MONOLITH TEAM — Social Network Analyzer

Project structure

```
index.html        page markup
css/style.css     all styles and animations
js/script.js      all behaviour (graph, BFS/DFS/Dijkstra, slides, music, effects)
assets/           images, slides (98 WebP), videos, song, team photos
```

How to run
- Double-click `index.html` (works offline), or
- serve the folder, e.g. `python3 -m http.server 8000` and open http://localhost:8000

Keep the folder structure together — the page loads files from `assets/` by relative path.
